class Prediction {
  final String id;
  final String title;
  final List<int> numbers;
  final String lottery;
  final bool isVIP;

  Prediction({required this.id, required this.title, required this.numbers, required this.lottery, this.isVIP = false});
}