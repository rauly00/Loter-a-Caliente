class UserPreferences {
  bool notificationsEnabled;
  String country;
  List<String> favoritePredictions;
  bool isVIP;

  UserPreferences({
    this.notificationsEnabled = true,
    this.country = "Cuba",
    this.favoritePredictions = const [],
    this.isVIP = false,
  });
}