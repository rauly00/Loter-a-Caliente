import 'package:cloud_firestore/cloud_firestore.dart';

class UserService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final String deviceId;

  UserService({required this.deviceId});

  Future<void> savePreferences(Map<String, dynamic> data) async {
    await _db.collection('users').doc(deviceId).set(data, SetOptions(merge: true));
  }

  Stream<Map<String, dynamic>> getPreferences() {
    return _db.collection('users').doc(deviceId).snapshots().map((doc) => doc.data() ?? {});
  }
}