import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/chat_message.dart';

class ChatService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<ChatMessage>> getMessages() {
    return _db.collection('chat')
      .orderBy('timestamp', descending: true)
      .snapshots()
      .map((snapshot) => snapshot.docs.map((doc) {
        final data = doc.data();
        return ChatMessage(
          sender: data['sender'],
          message: data['message'],
          timestamp: (data['timestamp'] as Timestamp).toDate(),
        );
      }).toList());
  }

  Future<void> sendMessage(String sender, String message) async {
    await _db.collection('chat').add({
      'sender': sender,
      'message': message,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }
}